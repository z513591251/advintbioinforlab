#' Explanation of crisprpred_main functions
#'
#' This function takes nothing. It performs all funtionalities of crisprpred.
#' @return None
#' @export
#' @examples 
#' crisprpred_main()

crisprpred_main = function(){
  #featuredata = read.csv(datasetpath)
  #featuredata = featurization(dataset, featurelist)
  #write.csv(featuredata, datasetpath, row.names = FALSE)
  nameofgene = c(
    "CD5", "NF1", "CUL3", "MED12", "TADA2B", "TADA1" , "CD45", "HPRT1", "THY1", "H2-K", "CD28", "NF2", "CD43", "CD33", "CD13", "CCDC101", "CD15"
  )
  #lmregression(featurelist, featuredata)
  #svmregression(featurelist, featuredata)

}
