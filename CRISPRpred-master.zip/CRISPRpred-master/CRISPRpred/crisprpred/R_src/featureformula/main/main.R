source('../featureformula.R')
featurelist = c('X1', 'X2', 'X3', 'Y')
formula=featureformula(featurelist)
formula
