source('../rmse.R')
rmse(4)
