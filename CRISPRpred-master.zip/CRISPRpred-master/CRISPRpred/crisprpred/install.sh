#!/usr/bin/env bash
# vim: set noexpandtab tabstop=2:
R CMD INSTALL --preclean --no-multiarch .
