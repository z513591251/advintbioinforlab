#!/usr/bin/env bash
# vim: set noexpandtab tabstop=2:

R -e 'roxygen2::roxygenize(".")'

