# 1.0.0
* Added some small tests for release, reduced settings.pred_test_num to make tests run faster

# 0.2.0
* Changed back to using version 1 of Haeussler data (and version 2 of Guide-seq, as before)
* Re-added Box-Cox transform to prediction preprocessing
* Set renormalize_guideseq back to True

# 0.1.1
* Tests added for aggregation.
* Random seed experiments conducted.
* Random seed added to LassoCV (no impact on predictions).
* Stronger tests added to guide sequence predictions.

# 0.1.0
* Initial version.
