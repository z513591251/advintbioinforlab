# Lindel
Lindel is a Logistic regression model to predict insertions and deletions induced by CRISPR/Cas9 editing. 

To use the tool simply type: 

```
git clone https://github.com/shendurelab/Lindel.git 
cd Lindel
python setup.py install
```

Please see full documentation at Lindel webpage.
