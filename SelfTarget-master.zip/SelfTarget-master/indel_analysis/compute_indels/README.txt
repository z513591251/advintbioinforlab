For example: 

run_example.py

Otherwise script order:

run_all_pear.py
run_all_partition.py
run_all_map.py
run_all_split_null_mappings.py
run_all_mapped_split.py
run_all_compile_nulls.py
run_all_indelmap.py
